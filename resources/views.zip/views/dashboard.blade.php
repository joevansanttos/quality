@extends('principal')

@section("cabecalho")
<h3>Dashboard</h3>
@stop

@section("conteudo")

@stop